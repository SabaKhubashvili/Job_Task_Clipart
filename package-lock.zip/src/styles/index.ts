export const Styles = {
    Width:'lg:max-w-[1312px] extramd:max-w-[1128px] md:max-w-[928px] sm:max-w-[328px]'
}